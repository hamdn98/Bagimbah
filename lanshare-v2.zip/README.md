# LanShare
Kirim file dan aplikasi terpasang HP ke HP lewat WiFi, hotspot HP, atau Wi-Fi Direct.

- Penemuan otomatis: UDP broadcast + pindai subnet (port 38555) + tambah manual lewat IP
- Tab **Direct**: sambung HP ke HP tanpa router (Wi-Fi Direct)
- Service latar belakang + WifiLock supaya transfer cepat dan tidak putus saat layar mati

Build: push ke GitHub, Actions menghasilkan APK (Artifacts > LanShare-apk). Lokal: `gradle assembleRelease`.
