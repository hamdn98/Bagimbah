package app.lanshare

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.ui.Modifier
import java.io.File

data class AppEntry(val pkg: String, val label: String, val parts: List<File>) {
    val size get() = parts.sumOf { it.length() }
}

fun loadApps(c: Context): List<AppEntry> {
    val pm = c.packageManager
    return pm.getInstalledApplications(0)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != c.packageName }
        .map { ai ->
            AppEntry(
                ai.packageName,
                pm.getApplicationLabel(ai).toString(),
                listOf(File(ai.sourceDir)) + (ai.splitSourceDirs?.map { s -> File(s) } ?: emptyList())
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun fmt(n: Long): String = when {
    n >= 1L shl 30 -> "%.1f GB".format(n / 1073741824.0)
    n >= 1L shl 20 -> "%.1f MB".format(n / 1048576.0)
    else -> "${n / 1024} KB"
}

fun Modifier.clickableItem(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))
