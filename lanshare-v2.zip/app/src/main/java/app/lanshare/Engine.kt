package app.lanshare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import java.io.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

data class Peer(val name: String, val host: String, val port: Int)
sealed interface Sendable { val label: String; val size: Long }
class FileItem(val uri: Uri, override val label: String, override val size: Long) : Sendable
class AppItem(val pkg: String, override val label: String, val parts: List<File>) : Sendable {
    override val size get() = parts.sumOf { it.length() }
}
data class Offer(val from: String, val count: Int, val total: Long, val answer: CompletableDeferred<Boolean>)
/** state: 0 jalan, 1 selesai, 2 gagal */
data class Xfer(val id: Long, val title: String, val outgoing: Boolean, val done: Long, val total: Long, val speed: Double, val state: Int)

/**
 * Mesin LanShare.
 * Penemuan perangkat memakai 3 cara sekaligus supaya jalan di WiFi biasa, hotspot HP, dan Wi-Fi Direct:
 *  1. UDP broadcast (beacon) di semua antarmuka (wlan, ap/hotspot, p2p)
 *  2. Pindai subnet (TCP ping ke port tetap) -> tembus walau broadcast diblokir
 *  3. Tambah manual lewat IP
 */
object Engine {
    const val PORT = 38555
    const val CH_LIVE = "live"
    const val CH_OFFER = "offer"
    private val IFACES = listOf("wlan", "ap", "swlan", "softap", "p2p", "rndis", "eth", "usb", "bt-pan")

    val peers = MutableStateFlow<List<Peer>>(emptyList())
    val xfers = MutableStateFlow<List<Xfer>>(emptyList())
    val incoming = MutableStateFlow<Offer?>(null)
    val myIps = MutableStateFlow<List<String>>(emptyList())
    val scanning = MutableStateFlow(false)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val scanPool = Executors.newFixedThreadPool(32).asCoroutineDispatcher()
    private val scanMutex = Mutex()
    private lateinit var app: Context
    private var started = false
    private var myName = "Android"
    private var myPort = PORT
    private val myId = UUID.randomUUID().toString().take(8)
    private val seen = ConcurrentHashMap<String, Long>()

    fun start(c: Context) {
        if (started) return
        started = true
        app = c.applicationContext
        myName = Settings.Global.getString(app.contentResolver, "device_name") ?: Build.MODEL ?: "Android"
        createChannels()
        try {
            val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.createMulticastLock("lanshare").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        registerNetCallback()
        scope.launch { serve() }
    }

    private fun createChannels() {
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LIVE, "LanShare aktif", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_OFFER, "Permintaan menerima file", NotificationManager.IMPORTANCE_HIGH))
    }

    // ---------- kunci WiFi / CPU saat transfer (lebih cepat & stabil) ----------
    private var lockCount = 0
    private var wifiLock: WifiManager.WifiLock? = null
    private var cpuLock: PowerManager.WakeLock? = null

    @Synchronized private fun lockUp() {
        if (lockCount++ > 0) return
        try {
            val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "lanshare:xfer")
                .apply { setReferenceCounted(false); acquire() }
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lanshare:xfer")
                .apply { setReferenceCounted(false); acquire(4 * 60 * 60 * 1000L) }
        } catch (_: Exception) {}
    }

    @Synchronized private fun lockDown() {
        if (--lockCount > 0) return
        lockCount = 0
        try { wifiLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        try { cpuLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        wifiLock = null; cpuLock = null
    }

    // ---------- alamat lokal (WiFi, hotspot, Wi-Fi Direct) ----------
    private class Local(val ip: Inet4Address, val prefix: Int, val bcast: InetAddress?)

    private fun locals(): List<Local> {
        val out = ArrayList<Local>()
        try {
            val nis = NetworkInterface.getNetworkInterfaces()
            if (nis != null) for (ni in Collections.list(nis)) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (IFACES.none { n.startsWith(it) }) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress)
                        out += Local(a, ia.networkPrefixLength.toInt(), ia.broadcast)
                }
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) {
            try {
                val cm = app.getSystemService(ConnectivityManager::class.java)
                val net = cm.activeNetwork
                val wifi = cm.getNetworkCapabilities(net)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                if (wifi) cm.getLinkProperties(net)?.linkAddresses?.forEach { la ->
                    val a = la.address
                    if (a is Inet4Address && !a.isLoopbackAddress) out += Local(a, la.prefixLength, null)
                }
            } catch (_: Exception) {}
        }
        return out
    }

    private fun registerNetCallback() {
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java)
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            cm.registerNetworkCallback(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) { rescanSoon() }
                override fun onLinkPropertiesChanged(n: Network, lp: LinkProperties) { rescanSoon() }
            })
        } catch (_: Exception) {}
    }

    // ---------- daftar perangkat ----------
    private fun addPeer(name: String, host: String, port: Int) {
        if (myIps.value.contains(host)) return
        seen[host] = System.currentTimeMillis()
        val np = Peer(name, host, port)
        peers.update { l ->
            val cur = l.firstOrNull { it.host == host }
            when {
                cur == null -> l + np
                cur == np -> l
                else -> l.map { if (it.host == host) np else it }
            }
        }
    }

    private suspend fun reaper() {
        while (true) {
            delay(5000)
            val now = System.currentTimeMillis()
            peers.update { l -> l.filter { now - (seen[it.host] ?: 0L) < 40_000L } }
        }
    }

    // ---------- UDP beacon ----------
    private suspend fun beaconLoop() {
        try {
            DatagramSocket().use { s ->
                s.broadcast = true
                val all = InetAddress.getByName("255.255.255.255")
                while (true) {
                    val ls = locals()
                    myIps.value = ls.mapNotNull { it.ip.hostAddress }.distinct()
                    val data = "LS2|$myId|$myPort|$myName".toByteArray()
                    for (t in ls.mapNotNull { it.bcast } + all) {
                        try { s.send(DatagramPacket(data, data.size, t, PORT)) } catch (_: Exception) {}
                    }
                    delay(2000)
                }
            }
        } catch (_: Exception) {}
    }

    private fun listenBeacons() {
        try {
            val s = DatagramSocket(null).apply { reuseAddress = true; broadcast = true; bind(InetSocketAddress(PORT)) }
            s.use {
                val buf = ByteArray(512)
                while (true) {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    val f = String(p.data, 0, p.length).split("|", limit = 4)
                    if (f.size < 4 || f[0] != "LS2" || f[1] == myId) continue
                    val port = f[2].toIntOrNull() ?: continue
                    val host = p.address.hostAddress ?: continue
                    addPeer(f[3], host, port)
                }
            }
        } catch (_: Exception) {}
    }

    // ---------- pindai subnet ----------
    private fun toIp(a: Int) = "${(a ushr 24) and 255}.${(a ushr 16) and 255}.${(a ushr 8) and 255}.${a and 255}"

    private fun probe(host: String, port: Int): Boolean {
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), 400)
                s.soTimeout = 1500
                val out = DataOutputStream(s.getOutputStream())
                out.writeUTF("PING"); out.flush()
                val inp = DataInputStream(s.getInputStream())
                val name = inp.readUTF(); val id = inp.readUTF()
                if (id != myId) { addPeer(name, host, port); return true }
            }
        } catch (_: Exception) {}
        return false
    }

    private suspend fun scan() {
        if (!scanMutex.tryLock()) return
        try {
            scanning.value = true
            val targets = LinkedHashSet<String>()
            for (l in locals()) {
                val base = l.ip.address.fold(0) { acc, b -> (acc shl 8) or (b.toInt() and 255) }
                val prefix = if (l.prefix >= 24) minOf(l.prefix, 32) else 24
                val mask = -1 shl (32 - prefix)
                val net = base and mask
                val count = 1 shl (32 - prefix)
                for (i in 1 until count - 1) {
                    val a = net or i
                    if (a != base) targets += toIp(a)
                }
            }
            coroutineScope { for (h in targets) launch(scanPool) { probe(h, PORT) } }
        } finally {
            scanning.value = false
            scanMutex.unlock()
        }
    }

    private suspend fun scanLoop() {
        delay(800)
        while (true) { scan(); delay(15_000) }
    }

    fun rescan() { scope.launch { scan() } }
    fun rescanSoon() { scope.launch { delay(1500); scan(); delay(3500); scan() } }

    fun probeAsync(host: String) {
        scope.launch { repeat(6) { if (probe(host, PORT)) return@launch; delay(1500) } }
    }

    fun addManual(text: String, done: (Boolean) -> Unit) {
        val t = text.trim()
        val host = t.substringBefore(":")
        val port = t.substringAfter(":", "").toIntOrNull() ?: PORT
        scope.launch { done(host.isNotEmpty() && probe(host, port)) }
    }

    // ---------- penerima ----------
    private fun bindServer(port: Int) = ServerSocket().apply {
        reuseAddress = true
        receiveBufferSize = 1 shl 22
        bind(InetSocketAddress(port))
    }

    private suspend fun serve() {
        val server = try { bindServer(PORT) } catch (_: Exception) { bindServer(0) }
        myPort = server.localPort
        scope.launch { beaconLoop() }
        scope.launch { listenBeacons() }
        scope.launch { scanLoop() }
        scope.launch { reaper() }
        while (true) {
            val s = try { server.accept() } catch (_: Exception) { delay(500); continue }
            scope.launch { handle(s) }
        }
    }

    private fun handle(s: Socket) {
        var meter: Meter? = null
        var locked = false
        try {
            s.use {
                s.tcpNoDelay = true; s.soTimeout = 30000
                val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 18))
                val out = DataOutputStream(s.getOutputStream())
                val tag = inp.readUTF()
                if (tag == "PING") { out.writeUTF(myName); out.writeUTF(myId); out.flush(); return }
                if (tag != "LS1") return
                val from = inp.readUTF(); val count = inp.readInt(); val total = inp.readLong()
                val ans = CompletableDeferred<Boolean>()
                incoming.value = Offer(from, count, total, ans)
                notifyOffer(from, count)
                val ok = runBlocking { withTimeoutOrNull(30000) { ans.await() } } ?: false
                incoming.value = null
                cancelOffer()
                out.writeByte(if (ok) 1 else 0); out.flush()
                if (!ok) return
                lockUp(); locked = true
                meter = Meter(System.nanoTime(), "Dari $from", false, total).also { it.push(0) }
                val installs = mutableListOf<File>()
                loop@ while (true) {
                    when (inp.readByte().toInt()) {
                        0 -> {
                            val name = inp.readUTF(); val size = inp.readLong()
                            saveToDownloads(name, size, inp, meter!!)
                        }
                        1 -> {
                            inp.readUTF(); val pkg = inp.readUTF().replace(Regex("[^A-Za-z0-9._]"), "_"); val n = inp.readInt()
                            val dir = File(app.cacheDir, "inbox/$pkg").apply { deleteRecursively(); mkdirs() }
                            repeat(n) {
                                val fn = File(inp.readUTF()).name; val sz = inp.readLong()
                                File(dir, fn).outputStream().use { o -> copyN(inp, o, sz, meter!!) }
                            }
                            installs += dir
                        }
                        else -> break@loop
                    }
                }
                out.writeByte(1); out.flush()
                meter!!.push(1)
                installs.forEach { installApk(it) }
            }
        } catch (e: Exception) {
            incoming.value = null
            cancelOffer()
            meter?.push(2)
        } finally {
            if (locked) lockDown()
        }
    }

    private fun notifyOffer(from: String, count: Int) {
        try {
            val pi = PendingIntent.getActivity(
                app, 0,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(app, CH_OFFER)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("$from ingin mengirim")
                .setContentText("$count item · ketuk untuk menerima")
                .setContentIntent(pi).setAutoCancel(true).build()
            app.getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (_: Exception) {}
    }

    private fun cancelOffer() {
        try { app.getSystemService(NotificationManager::class.java).cancel(2) } catch (_: Exception) {}
    }

    private fun saveToDownloads(name: String, size: Long, inp: InputStream, m: Meter) {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, File(name).name)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/LanShare")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Gagal simpan")
        app.contentResolver.openOutputStream(uri)!!.use { copyN(inp, it, size, m) }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        app.contentResolver.update(uri, v, null, null)
    }

    private fun installApk(dir: File) {
        val pi = app.packageManager.packageInstaller
        val sid = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(sid).use { ses ->
            dir.listFiles()!!.forEach { f ->
                f.inputStream().use { i -> ses.openWrite(f.name, 0, f.length()).use { o -> i.copyTo(o, 1 shl 16); ses.fsync(o) } }
            }
            val it = Intent(app, InstallReceiver::class.java).setAction("app.lanshare.INSTALL")
            val pend = PendingIntent.getBroadcast(app, sid, it, PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            ses.commit(pend.intentSender)
        }
    }

    // ---------- pengirim ----------
    fun sendUris(p: Peer, uris: List<Uri>) {
        scope.launch {
            val items = uris.map { u ->
                app.contentResolver.query(u, null, null, null, null)?.use { c ->
                    c.moveToFirst()
                    val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val z = c.getColumnIndex(OpenableColumns.SIZE)
                    FileItem(u, if (n >= 0) c.getString(n) else "file", if (z >= 0) c.getLong(z) else 0L)
                } ?: FileItem(u, "file", 0L)
            }
            send(p, items)
        }
    }

    fun sendApps(p: Peer, apps: List<AppEntry>) {
        scope.launch { send(p, apps.map { AppItem(it.pkg, it.label, it.parts) }) }
    }

    private fun send(peer: Peer, items: List<Sendable>) {
        val total = items.sumOf { it.size }
        val title = if (items.size == 1) items[0].label else "${items.size} item"
        val meter = Meter(System.nanoTime(), "Ke ${peer.name}: $title", true, total)
        meter.push(0)
        lockUp()
        try {
            Socket().use { s ->
                s.tcpNoDelay = true; s.sendBufferSize = 1 shl 22
                s.connect(InetSocketAddress(peer.host, peer.port), 5000)
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 1 shl 18))
                val inp = DataInputStream(s.getInputStream())
                out.writeUTF("LS1"); out.writeUTF(myName); out.writeInt(items.size); out.writeLong(total); out.flush()
                s.soTimeout = 60000
                if (inp.readByte().toInt() != 1) throw IOException("Ditolak")
                for (x in items) when (x) {
                    is FileItem -> {
                        out.writeByte(0); out.writeUTF(x.label); out.writeLong(x.size)
                        app.contentResolver.openInputStream(x.uri)!!.use { copy(it, out, meter) }
                    }
                    is AppItem -> {
                        out.writeByte(1); out.writeUTF(x.label); out.writeUTF(x.pkg); out.writeInt(x.parts.size)
                        x.parts.forEach { f ->
                            out.writeUTF(f.name); out.writeLong(f.length())
                            f.inputStream().use { copy(it, out, meter) }
                        }
                    }
                }
                out.writeByte(2); out.flush()
                inp.readByte()
                meter.push(1)
            }
        } catch (e: Exception) { meter.push(2) } finally { lockDown() }
    }

    // ---------- util ----------
    private fun copy(i: InputStream, o: OutputStream, m: Meter) {
        val b = ByteArray(1 shl 19)
        while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); m.add(n) }
    }
    private fun copyN(i: InputStream, o: OutputStream, n: Long, m: Meter) {
        val b = ByteArray(1 shl 19); var left = n
        while (left > 0) {
            val r = i.read(b, 0, minOf(b.size.toLong(), left).toInt())
            if (r < 0) throw EOFException()
            o.write(b, 0, r); left -= r; m.add(r)
        }
    }

    private fun upd(x: Xfer) {
        xfers.update { l -> if (l.any { it.id == x.id }) l.map { if (it.id == x.id) x else it } else listOf(x) + l }
    }

    private class Meter(val id: Long, val title: String, val out: Boolean, val total: Long) {
        @Volatile var done = 0L
        private var last = 0L
        private val t0 = System.nanoTime()
        fun add(n: Int) {
            done += n
            val now = System.nanoTime()
            if (now - last > 200_000_000L) { last = now; push(0) }
        }
        fun push(state: Int) {
            val sec = maxOf((System.nanoTime() - t0) / 1e9, 0.001)
            upd(Xfer(id, title, out, done, total, done / 1048576.0 / sec, state))
        }
    }
}
