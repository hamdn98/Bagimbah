package app.lanshare

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller

class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1) == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            @Suppress("DEPRECATION")
            val ui = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
            ui?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(it) }
        }
    }
}
