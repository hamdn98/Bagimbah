package app.lanshare

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/** Menjaga LanShare tetap hidup di latar belakang supaya bisa menerima file saat layar mati / app diminimalkan. */
class KeepAliveService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Engine.start(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, Engine.CH_LIVE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("LanShare aktif")
            .setContentText("Siap menerima file")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
}
