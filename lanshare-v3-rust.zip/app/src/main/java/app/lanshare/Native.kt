package app.lanshare

/** Jembatan ke mesin transfer Rust (liblanshare_native.so). Kalau gagal dimuat, Engine pakai jalur Kotlin. */
object Native {
    val ok: Boolean = try { System.loadLibrary("lanshare_native"); true } catch (_: Throwable) { false }

    /** mode 0: file -> socket (sendfile), mode 1: socket -> file. Mengembalikan jumlah byte, atau nilai negatif jika gagal. */
    external fun pump(src: Int, dst: Int, len: Long, slot: Int, mode: Int): Long
    external fun slot(): Int
    external fun release(slot: Int)
    external fun progress(slot: Int): Long
    external fun inNs(slot: Int): Long
    external fun outNs(slot: Int): Long
    external fun setTimeout(fd: Int, secs: Int): Int
}
