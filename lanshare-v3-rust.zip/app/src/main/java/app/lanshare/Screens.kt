package app.lanshare

import android.Manifest
import android.content.pm.PackageManager
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap

@Composable
fun Header(title: String, sub: String) {
    Column(Modifier.padding(horizontal = 20.dp).statusBarsPadding().padding(top = 16.dp, bottom = 8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Radar() {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val c = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val r = size.minDimension / 2
        for (k in 0..2) {
            val q = (p + k / 3f) % 1f
            drawCircle(c.copy(alpha = (1 - q) * 0.4f), radius = r * q, style = Stroke(3.dp.toPx()))
        }
        drawCircle(c, radius = 10.dp.toPx())
    }
}

@Composable
fun PeerCard(p: Peer, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) { Text(p.name.take(1).uppercase(), fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium)
                Text(p.host, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Filled.Send, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun KirimScreen() {
    val peers by Engine.peers.collectAsState()
    val ips by Engine.myIps.collectAsState()
    val scanning by Engine.scanning.collectAsState()
    var target by remember { mutableStateOf<Peer?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val p = target
        if (p != null && uris.isNotEmpty()) Engine.sendUris(p, uris)
    }
    Column(Modifier.fillMaxSize()) {
        Header("Kirim", "WiFi, hotspot HP, atau Wi-Fi Direct")
        Radar()
        Row(Modifier.padding(start = 20.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (ips.isEmpty()) "Belum tersambung ke jaringan" else "IP kamu: ${ips.joinToString()}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            IconButton({ Engine.rescan() }) { Icon(Icons.Default.Refresh, "Pindai ulang") }
            IconButton({ showAdd = true }) { Icon(Icons.Default.Add, "Tambah lewat IP") }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            if (peers.isEmpty()) {
                Text(
                    if (scanning) "Memindai jaringan…"
                    else "Belum ada perangkat. Buka LanShare di HP lain dan satukan jaringan: WiFi yang sama, hotspot (HP lain sambung ke hotspot), atau tab Direct. Tidak muncul? Tekan pindai ulang atau tambah lewat IP.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LazyColumn {
                items(peers, key = { it.host }) { p -> PeerCard(p) { target = p; picker.launch(arrayOf("*/*")) } }
            }
        }
    }
    if (showAdd) AddIpDialog { showAdd = false }
}

@Composable
fun AddIpDialog(onDismiss: () -> Unit) {
    var ip by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah lewat IP") },
        text = {
            Column {
                Text("Isi IP HP tujuan (tertulis di layar Kirim HP itu).", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    ip, { ip = it }, singleLine = true, placeholder = { Text("192.168.43.1") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                msg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton({
                msg = null
                Engine.addManual(ip) { ok -> if (ok) onDismiss() else msg = "Tidak ditemukan. Pastikan LanShare terbuka di HP itu." }
            }) { Text("Tambah") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } }
    )
}

private fun p2pState(s: Int) = when (s) {
    WifiP2pDevice.CONNECTED -> "Terhubung"
    WifiP2pDevice.INVITED -> "Diundang"
    WifiP2pDevice.FAILED -> "Gagal"
    WifiP2pDevice.UNAVAILABLE -> "Tidak tersedia"
    else -> "Tersedia"
}

@Composable
fun DirectScreen() {
    val ctx = LocalContext.current
    val devs by P2p.devices.collectAsState()
    val st by P2p.status.collectAsState()
    val on by P2p.enabled.collectAsState()
    val conn by P2p.connected.collectAsState()
    val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) P2p.discover() else P2p.status.value = "Izin diperlukan untuk Wi-Fi Direct"
    }
    val start = {
        P2p.init(ctx)
        if (perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }) P2p.discover()
        else launcher.launch(perms)
    }
    LaunchedEffect(Unit) { start() }

    Column(Modifier.fillMaxSize()) {
        Header("Wi-Fi Direct", "Sambung HP ke HP tanpa router / hotspot")
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(
                if (!on) "Wi-Fi Direct mati. Nyalakan WiFi dulu." else st,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton({ start() }) { Text("Cari ulang") }
                if (conn) OutlinedButton({ P2p.disconnect() }) { Text("Putuskan") }
            }
            if (conn) {
                Spacer(Modifier.height(8.dp))
                Text("Sudah terhubung. Buka tab Kirim, HP tujuan muncul otomatis.", color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn {
                items(devs, key = { it.deviceAddress }) { d ->
                    ElevatedCard(
                        onClick = { P2p.connect(d) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(d.deviceName.ifBlank { d.deviceAddress }, style = MaterialTheme.typography.titleMedium)
                            Text(p2pState(d.status), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AplikasiScreen() {
    val ctx = LocalContext.current
    val apps by produceState(emptyList<AppEntry>()) { value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { loadApps(ctx) } }
    val peers by Engine.peers.collectAsState()
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var sheet by remember { mutableStateOf(false) }
    val shown = apps.filter { it.label.contains(q, true) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header("Aplikasi", "Pilih aplikasi terpasang untuk dikirim")
            OutlinedTextField(
                q, { q = it }, singleLine = true, placeholder = { Text("Cari aplikasi") },
                shape = CircleShape, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)
            )
            LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp)) {
                items(shown, key = { it.pkg }) { a ->
                    val icon = remember(a.pkg) { ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }
                    ListItem(
                        leadingContent = { Image(icon, null, Modifier.size(44.dp)) },
                        headlineContent = { Text(a.label) },
                        supportingContent = { Text(fmt(a.size) + if (a.parts.size > 1) " · split" else "") },
                        trailingContent = { Checkbox(a.pkg in sel, null) },
                        modifier = Modifier.clip(MaterialTheme.shapes.large).clickableItem {
                            sel = if (a.pkg in sel) sel - a.pkg else sel + a.pkg
                        }
                    )
                }
            }
        }
        if (sel.isNotEmpty()) {
            ExtendedFloatingActionButton(
                onClick = { sheet = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
            ) { Text("Kirim ${sel.size} aplikasi") }
        }
    }
    if (sheet) ModalBottomSheet(onDismissRequest = { sheet = false }) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Kirim ke…", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (peers.isEmpty()) Text("Belum ada perangkat terdekat.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            peers.forEach { p ->
                PeerCard(p) {
                    Engine.sendApps(p, apps.filter { it.pkg in sel })
                    sel = emptySet(); sheet = false
                }
            }
        }
    }
}

@Composable
fun RiwayatScreen() {
    val xs by Engine.xfers.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Header("Riwayat", "Transfer yang sedang dan sudah berjalan")
        if (xs.isEmpty()) Text("Belum ada transfer.", Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
            items(xs, key = { it.id }) { x ->
                ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(x.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { if (x.total > 0) (x.done.toFloat() / x.total).coerceIn(0f, 1f) else 0f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(6.dp))
                        val st = when (x.state) {
                            1 -> "Selesai · ${fmt(x.total)}"
                            2 -> "Gagal atau ditolak"
                            else -> "${fmt(x.done)} / ${fmt(x.total)} · %.1f MB/s".format(x.speed)
                        }
                        Text(st, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (x.note.isNotBlank()) Text(x.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
