//! LanShare: jalur data (kirim/terima) dalam Rust.
//! Tanpa dependensi. Hanya tipe primitif yang lewat JNI, jadi tidak perlu crate `jni`.
//! - Kirim  (mode 0): file -> socket memakai sendfile (zero-copy), fallback read/write
//! - Terima (mode 1): socket -> file memakai read/write buffer 1 MB
//! Progres dan waktu tunggu dibaca Kotlin lewat slot atomik.

use std::cmp::min;
use std::os::raw::{c_int, c_long, c_void};
use std::sync::atomic::{AtomicBool, AtomicI64, Ordering};
use std::time::Instant;

const N: usize = 64;
const ZB: AtomicBool = AtomicBool::new(false);
const ZI: AtomicI64 = AtomicI64::new(0);
static USED: [AtomicBool; N] = [ZB; N];
static PROG: [AtomicI64; N] = [ZI; N];
static IN_NS: [AtomicI64; N] = [ZI; N];
static OUT_NS: [AtomicI64; N] = [ZI; N];

const EINTR: i32 = 4;
const EAGAIN: i32 = 11;

extern "C" {
    fn read(fd: c_int, buf: *mut c_void, n: usize) -> isize;
    fn write(fd: c_int, buf: *const c_void, n: usize) -> isize;
    fn sendfile(out_fd: c_int, in_fd: c_int, off: *mut c_void, count: usize) -> isize;
    fn setsockopt(fd: c_int, level: c_int, name: c_int, val: *const c_void, len: u32) -> c_int;
}

#[repr(C)]
struct TimeVal {
    sec: c_long,
    usec: c_long,
}

fn errno() -> i32 {
    std::io::Error::last_os_error().raw_os_error().unwrap_or(0)
}

fn add(a: &AtomicI64, t: Instant) {
    a.fetch_add(t.elapsed().as_nanos() as i64, Ordering::Relaxed);
}

/// Tulis semua byte ke fd. Mengembalikan 0 jika sukses, atau -errno.
fn write_all(fd: c_int, mut b: &[u8], slot: usize) -> i64 {
    while !b.is_empty() {
        let t = Instant::now();
        let n = unsafe { write(fd, b.as_ptr() as *const c_void, b.len()) };
        let e = errno();
        add(&OUT_NS[slot], t);
        if n < 0 {
            if e == EINTR {
                continue;
            }
            return -(e.max(1) as i64);
        }
        if n == 0 {
            return -1000;
        }
        b = &b[n as usize..];
    }
    0
}

fn copy_rw(src: c_int, dst: c_int, len: i64, slot: usize) -> i64 {
    let mut buf = vec![0u8; 1 << 20];
    let mut done: i64 = 0;
    while done < len {
        let want = min(buf.len() as i64, len - done) as usize;
        let t = Instant::now();
        let n = unsafe { read(src, buf.as_mut_ptr() as *mut c_void, want) };
        let e = errno();
        add(&IN_NS[slot], t);
        if n < 0 {
            if e == EINTR {
                continue;
            }
            return -(e.max(1) as i64);
        }
        if n == 0 {
            return -1000; // koneksi / file berakhir sebelum waktunya
        }
        let w = write_all(dst, &buf[..n as usize], slot);
        if w < 0 {
            return w;
        }
        done += n as i64;
        PROG[slot].store(done, Ordering::Relaxed);
    }
    done
}

fn send_file(src: c_int, dst: c_int, len: i64, slot: usize) -> i64 {
    let mut done: i64 = 0;
    while done < len {
        let want = min(4 << 20, len - done) as usize;
        let t = Instant::now();
        let n = unsafe { sendfile(dst, src, std::ptr::null_mut(), want) };
        let e = errno();
        add(&OUT_NS[slot], t);
        if n < 0 {
            if e == EINTR {
                continue;
            }
            if done == 0 && e != EAGAIN {
                return copy_rw(src, dst, len, slot); // sendfile tidak didukung untuk fd ini
            }
            return -(e.max(1) as i64);
        }
        if n == 0 {
            return -1000;
        }
        done += n as i64;
        PROG[slot].store(done, Ordering::Relaxed);
    }
    done
}

#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_pump(
    _env: *mut c_void,
    _cls: *mut c_void,
    src: i32,
    dst: i32,
    len: i64,
    slot: i32,
    mode: i32,
) -> i64 {
    if slot < 0 || slot as usize >= N {
        return -1;
    }
    let s = slot as usize;
    if mode == 0 {
        send_file(src, dst, len, s)
    } else {
        copy_rw(src, dst, len, s)
    }
}

#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_slot(_env: *mut c_void, _cls: *mut c_void) -> i32 {
    for i in 0..N {
        if USED[i]
            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .is_ok()
        {
            PROG[i].store(0, Ordering::Relaxed);
            IN_NS[i].store(0, Ordering::Relaxed);
            OUT_NS[i].store(0, Ordering::Relaxed);
            return i as i32;
        }
    }
    -1
}

#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_release(_env: *mut c_void, _cls: *mut c_void, slot: i32) {
    if slot >= 0 && (slot as usize) < N {
        USED[slot as usize].store(false, Ordering::Release);
    }
}

#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_progress(_env: *mut c_void, _cls: *mut c_void, slot: i32) -> i64 {
    if slot < 0 || slot as usize >= N { return 0; }
    PROG[slot as usize].load(Ordering::Relaxed)
}

#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_inNs(_env: *mut c_void, _cls: *mut c_void, slot: i32) -> i64 {
    if slot < 0 || slot as usize >= N { return 0; }
    IN_NS[slot as usize].load(Ordering::Relaxed)
}

#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_outNs(_env: *mut c_void, _cls: *mut c_void, slot: i32) -> i64 {
    if slot < 0 || slot as usize >= N { return 0; }
    OUT_NS[slot as usize].load(Ordering::Relaxed)
}

/// Batas waktu baca/tulis socket (detik), supaya transfer yang macet tidak menggantung selamanya.
#[no_mangle]
pub extern "C" fn Java_app_lanshare_Native_setTimeout(_env: *mut c_void, _cls: *mut c_void, fd: i32, secs: i32) -> i32 {
    let tv = TimeVal { sec: secs as c_long, usec: 0 };
    let p = &tv as *const TimeVal as *const c_void;
    let sz = std::mem::size_of::<TimeVal>() as u32;
    let a = unsafe { setsockopt(fd, 1, 20, p, sz) }; // SOL_SOCKET, SO_RCVTIMEO
    let b = unsafe { setsockopt(fd, 1, 21, p, sz) }; // SOL_SOCKET, SO_SNDTIMEO
    if a == 0 && b == 0 { 0 } else { -1 }
}
