# LanShare
Kirim file dan aplikasi terpasang HP ke HP lewat WiFi, hotspot HP, atau Wi-Fi Direct.

- Penemuan otomatis: UDP broadcast + pindai subnet (port 38555) + tambah manual lewat IP
- Tab **Direct**: sambung HP ke HP tanpa router (Wi-Fi Direct)
- Service latar belakang + WifiLock supaya transfer cepat dan tidak putus saat layar mati

Build: push ke GitHub, Actions menghasilkan APK (Artifacts > LanShare-apk). Lokal: `gradle assembleRelease`.

## Mesin Rust
Jalur data transfer ada di `native/` (Rust, tanpa dependensi, sendfile zero-copy). CI membangunnya dengan `cargo-ndk` ke `app/src/main/jniLibs`. Kalau library tidak ada (build lokal tanpa Rust), aplikasi otomatis memakai jalur Kotlin.

## Versi Windows 11
Folder `windows/` (Python + tkinter, protokol sama dengan HP). CI `windows.yml` membuat `LanShare.exe` (Artifacts > LanShare-windows).
Jalankan lokal: `windows\run.bat`. Saat pertama dibuka, izinkan di Windows Firewall (jaringan Private).
