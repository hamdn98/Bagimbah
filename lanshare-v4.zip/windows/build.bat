@echo off
rem Bangun LanShare.exe sendiri di Windows (butuh Python 3)
cd /d %~dp0
pip install pyinstaller pillow
python make_icon.py
pyinstaller --onefile --noconsole --name LanShare --icon icon.ico --add-data "icon.ico;." app.py
echo Selesai: dist\LanShare.exe
