"""Membuat icon.ico (logo LanShare: sinyal WiFi + panah tukar) dengan Pillow."""
from PIL import Image, ImageDraw

S = 1024  # kanvas besar lalu diperkecil (anti-alias)
k = S / 108.0

def logo():
    bg = Image.new("RGB", (S, S))
    px = bg.load()
    a, b = (0x00, 0xC2, 0xA8), (0x5B, 0x3B, 0xDB)
    for y in range(S):
        for x in range(S):
            t = (x + y) / (2.0 * S)
            px[x, y] = tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, S - 1, S - 1), radius=int(S * 0.22), fill=255)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0)); img.paste(bg, (0, 0), mask)
    d = ImageDraw.Draw(img); w = int(4.5 * k); white = (255, 255, 255, 255)
    cx, cy = 54 * k, 52 * k
    for r in (9, 17, 25):  # busur WiFi: 225..315 derajat
        R = r * k
        Ro = R + w / 2  # PIL menggambar garis ke arah dalam dari bbox; geser agar tengah garis tepat di radius R
        d.arc((cx - Ro, cy - Ro, cx + Ro, cy + Ro), 225, 315, fill=white, width=w)
        for ang in (225, 315):  # ujung membulat
            import math
            ex, ey = cx + R * math.cos(math.radians(ang)), cy + R * math.sin(math.radians(ang))
            d.ellipse((ex - w / 2, ey - w / 2, ex + w / 2, ey + w / 2), fill=white)
    d.ellipse((cx - 3.5 * k, cy - 3.5 * k, cx + 3.5 * k, cy + 3.5 * k), fill=white)
    def line(pts):
        d.line([(x * k, y * k) for x, y in pts], fill=white, width=w, joint="curve")
        for x, y in pts: d.ellipse((x * k - w / 2, y * k - w / 2, x * k + w / 2, y * k + w / 2), fill=white)
    line([(38, 65), (70, 65)]); line([(63, 59), (70, 65), (63, 71)])
    line([(70, 78), (38, 78)]); line([(45, 72), (38, 78), (45, 84)])
    return img

if __name__ == "__main__":
    im = logo()
    im.resize((256, 256), Image.LANCZOS).save("icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    im.resize((512, 512), Image.LANCZOS).save("logo_preview.png")
    print("icon.ico + logo_preview.png dibuat")
