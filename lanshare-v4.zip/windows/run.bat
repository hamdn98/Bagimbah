@echo off
rem Jalankan tanpa build (butuh Python 3 dari python.org, centang "tcl/tk")
cd /d %~dp0
python app.py
