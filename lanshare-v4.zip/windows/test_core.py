"""Tes protokol tanpa GUI: meniru sisi Android memakai format byte Java yang sama."""
import os, socket, struct, tempfile, threading, time
from core import *

def test_utf():
    assert jutf_enc("A") == b"\x00\x01A"
    assert jutf_enc("é")[2:] == b"\xc3\xa9"
    assert jutf_enc("\u0000")[2:] == b"\xc0\x80"
    assert jutf_enc("😀")[2:] == bytes.fromhex("eda0bdedb880")  # surrogate pair 3+3 byte, ala Java
    for s in ["", "halo", "Galaxy A72", "é漢字😀\u0000x"]:
        e = jutf_enc(s)
        assert jutf_dec(e[2:]) == s

def mk(tmp):
    d = os.path.join(tmp, "rx"); n = Node(name="Laptop", save_dir=d, port=0, discovery=False)
    n.start(); return n

def test_ping_and_android_to_laptop():
    with tempfile.TemporaryDirectory() as tmp:
        n = mk(tmp)
        # PING seperti probe Android
        s = socket.create_connection(("127.0.0.1", n.port)); s.sendall(jutf_enc("PING"))
        assert read_utf(s) == "Laptop"; assert read_utf(s) == n.id; s.close()
        # Android -> laptop: 1 file biasa + 1 aplikasi 2 bagian
        data = os.urandom(3_000_000 + 17); apk1 = os.urandom(5000); apk2 = os.urandom(777)
        total = len(data) + len(apk1) + len(apk2)
        s = socket.create_connection(("127.0.0.1", n.port))
        s.sendall(jutf_enc("LS1") + jutf_enc("Galaxy A72") + struct.pack(">iq", 2, total))
        assert rd(s, 1) == b"\x01"
        s.sendall(b"\x00" + jutf_enc("foto ../bagus:1.bin") + struct.pack(">q", len(data)) + data)
        s.sendall(b"\x01" + jutf_enc("WhatsApp") + jutf_enc("com.whatsapp") + struct.pack(">i", 2)
                  + jutf_enc("base.apk") + struct.pack(">q", len(apk1)) + apk1
                  + jutf_enc("split_x.apk") + struct.pack(">q", len(apk2)) + apk2)
        s.sendall(b"\x02"); assert rd(s, 1) == b"\x01"; s.close()
        rx = os.path.join(tmp, "rx")
        assert open(os.path.join(rx, "bagus_1.bin"), "rb").read() == data
        assert open(os.path.join(rx, "Aplikasi", "com.whatsapp", "base.apk"), "rb").read() == apk1
        assert open(os.path.join(rx, "Aplikasi", "com.whatsapp", "split_x.apk"), "rb").read() == apk2
        time.sleep(0.2); assert n.xfers[0].state == 1

def test_reject():
    with tempfile.TemporaryDirectory() as tmp:
        n = Node(name="L", save_dir=tmp, port=0, discovery=False, on_offer=lambda *a: False); n.start()
        s = socket.create_connection(("127.0.0.1", n.port))
        s.sendall(jutf_enc("LS1") + jutf_enc("X") + struct.pack(">iq", 1, 10)); assert rd(s, 1) == b"\x00"

def test_laptop_to_android():
    """Server tiruan memakai urutan baca persis seperti Engine.handle() di Android."""
    with tempfile.TemporaryDirectory() as tmp:
        f1 = os.path.join(tmp, "a.bin"); f2 = os.path.join(tmp, "b.txt")
        d1 = os.urandom(2_500_000); d2 = b"halo"
        open(f1, "wb").write(d1); open(f2, "wb").write(d2)
        srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(1); got = {}
        def android():
            c, _ = srv.accept()
            assert read_utf(c) == "LS1"; got["from"] = read_utf(c)
            cnt, tot = struct.unpack(">iq", rd(c, 12)); got["cnt"], got["tot"] = cnt, tot
            c.sendall(b"\x01"); files = {}
            while True:
                k = rd(c, 1)[0]
                if k == 0:
                    nm = read_utf(c); (sz,) = struct.unpack(">q", rd(c, 8)); files[nm] = rd(c, sz)
                else: break
            c.sendall(b"\x01"); got["files"] = files
        t = threading.Thread(target=android); t.start()
        n = Node(name="Laptop", port=0, discovery=False)
        x = n.send_files("127.0.0.1", srv.getsockname()[1], [f1, f2]); t.join(10)
        assert x.state == 1, x.err
        assert got["from"] == "Laptop" and got["cnt"] == 2 and got["tot"] == len(d1) + 4
        assert got["files"] == {"a.bin": d1, "b.txt": d2}

def test_speed_loopback():
    with tempfile.TemporaryDirectory() as tmp:
        big = os.path.join(tmp, "big.bin"); open(big, "wb").write(os.urandom(200 * MB.__int__()))
        rx = mk(tmp); tx = Node(name="T", port=0, discovery=False)
        x = tx.send_files("127.0.0.1", rx.port, [big]); time.sleep(0.3)
        assert x.state == 1, x.err
        print(f"  loopback 200 MB: {x.speed:.0f} MB/s"); assert rx.xfers[0].state == 1

if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"): v(); print("OK", k)
