"""LanShare untuk Windows: protokol yang sama dengan aplikasi Android.
Port 38555 (TCP transfer + UDP beacon). Hanya library standar Python."""
import itertools
import os
import socket
import struct
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

PORT = 38555
MB = 1048576.0
CHUNK = 1 << 20
PAR = 4            # jumlah koneksi paralel
PCHUNK = 4 << 20   # ukuran potongan per frame (4 MB)


class _Fallback(Exception):
    """Penerima versi lama (tidak mengerti LS3): ulangi dengan jalur biasa."""


# ---------- Java modified UTF-8 (DataInput/OutputStream.readUTF/writeUTF) ----------
def jutf_enc(s: str) -> bytes:
    out = bytearray()
    u16 = s.encode("utf-16-be", "surrogatepass")
    for i in range(0, len(u16), 2):
        cu = (u16[i] << 8) | u16[i + 1]
        if 1 <= cu <= 0x7F:
            out.append(cu)
        elif cu <= 0x7FF:  # termasuk U+0000 -> C0 80
            out += bytes((0xC0 | (cu >> 6), 0x80 | (cu & 0x3F)))
        else:
            out += bytes((0xE0 | (cu >> 12), 0x80 | ((cu >> 6) & 0x3F), 0x80 | (cu & 0x3F)))
    return struct.pack(">H", len(out)) + bytes(out)


def jutf_dec(b: bytes) -> str:
    units = []
    i = 0
    while i < len(b):
        c = b[i]
        if c < 0x80:
            units.append(c); i += 1
        elif c >> 5 == 0b110:
            units.append(((c & 0x1F) << 6) | (b[i + 1] & 0x3F)); i += 2
        else:
            units.append(((c & 0x0F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F)); i += 3
    raw = b"".join(struct.pack(">H", u) for u in units)
    return raw.decode("utf-16-be", "replace")


def rd(sock, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        part = sock.recv(n - len(buf))
        if not part:
            raise EOFError("koneksi terputus")
        buf += part
    return bytes(buf)


def read_utf(sock) -> str:
    (n,) = struct.unpack(">H", rd(sock, 2))
    return jutf_dec(rd(sock, n))


def safe_name(name: str, default="file") -> str:
    n = os.path.basename(name.replace("\\", "/"))
    n = "".join("_" if c in '<>:"/\\|?*' or ord(c) < 32 else c for c in n).strip(" .")
    return n or default


def unique_path(path: str) -> str:
    base, ext = os.path.splitext(path)
    i = 1
    while os.path.exists(path):
        path = f"{base} ({i}){ext}"
        i += 1
    return path


def local_ips():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # tidak mengirim paket; hanya memilih antarmuka
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127.") and not i.startswith("169.254."))


class Xfer:
    _ids = itertools.count(1)

    def __init__(self, title, outgoing, total):
        self.id = next(Xfer._ids)
        self.title, self.outgoing, self.total = title, outgoing, total
        self.done = 0
        self.state = 0  # 0 jalan, 1 selesai, 2 gagal
        self.speed = 0.0
        self.err = ""
        self.lock = threading.Lock()
        self.start()

    def start(self):
        self.t0 = self.wt = time.monotonic()
        self.wd = self.done
        self.speed = 0.0

    def add(self, n):
        with self.lock:
            self.done += n
            now = time.monotonic()
            if now - self.wt >= 0.5:
                inst = (self.done - self.wd) / MB / (now - self.wt)
                self.speed = inst if self.speed == 0 else self.speed * 0.6 + inst * 0.4
                self.wt, self.wd = now, self.done

    def finish(self, state, err=""):
        self.state, self.err = state, err
        if state == 1:
            self.speed = self.done / MB / max(time.monotonic() - self.t0, 0.001)


class Session:
    """Satu pengiriman paralel: banyak koneksi menulis potongan ke file yang sama."""

    def __init__(self, files, total, x):
        self.files, self.total, self.x = files, total, x
        self.got = 0
        self.last = time.time()
        self.err = None
        self.lock = threading.Lock()

    def add(self, n):
        with self.lock:
            self.got += n
            self.last = time.time()
        self.x.add(n)


class Node:
    def __init__(self, name=None, save_dir=None, port=PORT, discovery=True, on_offer=None):
        self.name = name or socket.gethostname()
        self.save_dir = save_dir or os.path.join(os.path.expanduser("~"), "Downloads", "LanShare")
        self.want_port = port
        self.discovery = discovery
        self.on_offer = on_offer  # (from, count, total) -> bool, dipanggil di thread lain
        self.id = uuid.uuid4().hex[:8]
        self.port = port
        self.peers = {}  # host -> [name, port, seen]
        self.my_ips = []
        self.xfers = []
        self.scanning = False
        self.active = 0
        self.lock = threading.Lock()
        self.server = None
        self.parallel = PAR
        self.sessions = {}

    # ----- start -----
    def start(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 << 20)
        try:
            self.server.bind(("", self.want_port))
        except OSError:
            self.server.bind(("", 0))
        self.server.listen(16)
        self.port = self.server.getsockname()[1]
        self._thread(self._accept_loop)
        if self.discovery:
            for fn in (self._beacon_loop, self._listen_loop, self._scan_loop, self._reaper):
                self._thread(fn)

    @staticmethod
    def _thread(fn, *a):
        t = threading.Thread(target=fn, args=a, daemon=True)
        t.start()
        return t

    # ----- daftar perangkat -----
    def peer_list(self):
        with self.lock:
            return [(h, v[0], v[1]) for h, v in sorted(self.peers.items())]

    def _add_peer(self, name, host, port):
        if host in self.my_ips:
            return
        with self.lock:
            self.peers[host] = [name, port, time.time()]

    def _reaper(self):
        while True:
            time.sleep(5)
            now = time.time()
            with self.lock:
                for h in [h for h, v in self.peers.items() if now - v[2] > 40]:
                    del self.peers[h]

    # ----- discovery -----
    def _beacon_loop(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while True:
            self.my_ips = local_ips()
            data = f"LS2|{self.id}|{self.port}|{self.name}".encode()
            targets = {"255.255.255.255"} | {ip.rsplit(".", 1)[0] + ".255" for ip in self.my_ips}
            for t in targets:
                try:
                    s.sendto(data, (t, PORT))
                except OSError:
                    pass
            time.sleep(2)

    def _listen_loop(self):
        while True:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(("", PORT))
                while True:
                    data, addr = s.recvfrom(512)
                    f = data.decode("utf-8", "replace").split("|", 3)
                    if len(f) == 4 and f[0] == "LS2" and f[1] != self.id and f[2].isdigit():
                        self._add_peer(f[3], addr[0], int(f[2]))
            except OSError:
                time.sleep(3)

    def probe(self, host, port=PORT):
        try:
            with socket.create_connection((host, port), timeout=0.4) as s:
                s.settimeout(1.5)
                s.sendall(jutf_enc("PING"))
                name = read_utf(s)
                pid = read_utf(s)
            if pid == self.id:
                return False
            self._add_peer(name, host, port)
            return True
        except (OSError, EOFError, struct.error):
            return False

    def scan(self):
        if self.active > 0 or self.scanning:
            return
        self.scanning = True
        try:
            targets = []
            for ip in self.my_ips or local_ips():
                pre = ip.rsplit(".", 1)[0]
                targets += [f"{pre}.{i}" for i in range(1, 255) if f"{pre}.{i}" != ip]
            with ThreadPoolExecutor(64) as ex:
                list(ex.map(self.probe, targets))
        finally:
            self.scanning = False

    def _scan_loop(self):
        time.sleep(1)
        while True:
            self.scan()
            time.sleep(15)

    def add_manual(self, text):
        t = text.strip()
        host, _, p = t.partition(":")
        return bool(host) and self.probe(host, int(p) if p.isdigit() else PORT)

    # ----- terima -----
    def _accept_loop(self):
        while True:
            try:
                conn, _ = self.server.accept()
            except OSError:
                time.sleep(0.5)
                continue
            self._thread(self._handle, conn)

    def _recv_file(self, conn, path, size, x):
        buf = bytearray(CHUNK)
        mv = memoryview(buf)
        left = size
        with open(path, "wb", buffering=0) as f:
            while left > 0:
                n = conn.recv_into(mv, min(CHUNK, left))
                if n == 0:
                    raise EOFError("koneksi terputus")
                f.write(mv[:n])
                left -= n
                x.add(n)

    def _handle(self, conn):
        x = None
        counted = False
        try:
            with conn:
                conn.settimeout(30)
                tag = read_utf(conn)
                if tag == "PING":
                    conn.sendall(jutf_enc(self.name) + jutf_enc(self.id))
                    return
                if tag == "LS3":
                    self._handle_par(conn)
                    return
                if tag == "LS3D":
                    self._handle_data(conn)
                    return
                if tag != "LS1":
                    return
                frm = read_utf(conn)
                count, total = struct.unpack(">iq", rd(conn, 12))
                ok = self.on_offer(frm, count, total) if self.on_offer else True
                conn.sendall(b"\x01" if ok else b"\x00")
                if not ok:
                    return
                self.active += 1; counted = True
                conn.settimeout(60)
                x = Xfer(f"Dari {frm}", False, total)
                self._track(x)
                os.makedirs(self.save_dir, exist_ok=True)
                while True:
                    kind = rd(conn, 1)[0]
                    if kind == 0:
                        name = safe_name(read_utf(conn))
                        (size,) = struct.unpack(">q", rd(conn, 8))
                        self._recv_file(conn, unique_path(os.path.join(self.save_dir, name)), size, x)
                    elif kind == 1:  # aplikasi Android: disimpan sebagai file APK
                        read_utf(conn)
                        pkg = safe_name(read_utf(conn), "app")
                        (n,) = struct.unpack(">i", rd(conn, 4))
                        d = os.path.join(self.save_dir, "Aplikasi", pkg)
                        os.makedirs(d, exist_ok=True)
                        for _ in range(n):
                            fn = safe_name(read_utf(conn))
                            (size,) = struct.unpack(">q", rd(conn, 8))
                            self._recv_file(conn, unique_path(os.path.join(d, fn)), size, x)
                    else:
                        break
                conn.sendall(b"\x01")
                x.finish(1)
        except (OSError, EOFError, struct.error) as e:
            if x:
                x.finish(2, str(e))
        finally:
            if counted:
                self.active -= 1

    # ----- terima paralel (LS3) -----
    def _handle_par(self, conn):
        frm = read_utf(conn)
        count, total = struct.unpack(">iq", rd(conn, 12))
        ok = self.on_offer(frm, count, total) if self.on_offer else True
        conn.sendall(b"\x01" if ok else b"\x00")
        if not ok:
            return
        sid = uuid.uuid4().hex[:12]
        conn.sendall(jutf_enc(sid))
        conn.settimeout(30)
        table = []
        for _ in range(count):
            name = safe_name(read_utf(conn))
            (size,) = struct.unpack(">q", rd(conn, 8))
            table.append((name, size))
        os.makedirs(self.save_dir, exist_ok=True)
        files = []
        for name, size in table:
            p = unique_path(os.path.join(self.save_dir, name))
            with open(p, "wb") as f:
                f.truncate(size)
            files.append(p)
        x = Xfer(f"Dari {frm}", False, total)
        self._track(x)
        sess = Session(files, total, x)
        self.sessions[sid] = sess
        self.active += 1
        try:
            conn.sendall(b"\x01")
            conn.settimeout(5)
            while True:
                try:
                    k = rd(conn, 1)[0]
                    break
                except socket.timeout:
                    if sess.err:
                        raise OSError(sess.err)
                    if time.time() - sess.last > 60:
                        raise OSError("transfer macet")
            if k != 2 or sess.got < total:
                raise OSError(sess.err or "data tidak lengkap")
            conn.sendall(b"\x01")
            x.finish(1)
        except (OSError, EOFError, struct.error) as e:
            x.finish(2, str(e))
        finally:
            self.sessions.pop(sid, None)
            self.active -= 1

    def _handle_data(self, conn):
        sess = self.sessions.get(read_utf(conn))
        if sess is None:
            conn.sendall(b"\x00")
            return
        conn.sendall(b"\x01")
        conn.settimeout(60)
        handles = {}
        buf = bytearray(CHUNK)
        mv = memoryview(buf)
        try:
            while True:
                (idx,) = struct.unpack(">i", rd(conn, 4))
                if idx < 0:
                    break
                off, ln = struct.unpack(">qi", rd(conn, 12))
                f = handles.get(idx)
                if f is None:
                    f = handles[idx] = open(sess.files[idx], "r+b", buffering=0)
                f.seek(off)
                left = ln
                while left > 0:
                    n = conn.recv_into(mv, min(CHUNK, left))
                    if n == 0:
                        raise EOFError("koneksi terputus")
                    f.write(mv[:n])
                    left -= n
                    sess.add(n)
            conn.sendall(b"\x01")
        except (OSError, EOFError, struct.error) as e:
            sess.err = str(e) or "koneksi data putus"
        finally:
            for f in handles.values():
                f.close()

    # ----- kirim -----
    def _track(self, x):
        with self.lock:
            self.xfers.insert(0, x)

    def send_files(self, host, port, paths):
        items = [(safe_name(p), os.path.getsize(p), p) for p in paths]
        total = sum(i[1] for i in items)
        title = items[0][0] if len(items) == 1 else f"{len(items)} item"
        x = Xfer(f"Ke {host}: {title}", True, total)
        self._track(x)
        self.active += 1
        try:
            done = False
            if self.parallel > 1 and total >= (4 << 20):
                try:
                    self._send_par(host, port, items, total, x, self.parallel)
                    done = True
                except _Fallback:
                    pass
            if not done:
                self._send_legacy(host, port, items, total, x)
            x.finish(1)
        except Exception as e:
            x.finish(2, str(e) or e.__class__.__name__)
        finally:
            self.active -= 1
        return x

    def _send_par(self, host, port, items, total, x, n):
        ctl = socket.create_connection((host, port), timeout=5)
        try:
            ctl.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            ctl.settimeout(60)
            ctl.sendall(jutf_enc("LS3") + jutf_enc(self.name) + struct.pack(">iq", len(items), total))
            try:
                ack = rd(ctl, 1)
            except (EOFError, ConnectionError):
                raise _Fallback()
            if ack != b"\x01":
                raise OSError("Ditolak")
            sid = read_utf(ctl)
            ctl.sendall(b"".join(jutf_enc(nm) + struct.pack(">q", sz) for nm, sz, _ in items))
            if rd(ctl, 1) != b"\x01":
                raise OSError("Gagal menyiapkan penerima")
            x.start()
            chunks = [(i, off, min(PCHUNK, sz - off))
                      for i, (_, sz, _p) in enumerate(items) for off in range(0, sz, PCHUNK)]
            nxt = itertools.count()
            err = []

            def worker():
                try:
                    with socket.create_connection((host, port), timeout=5) as s:
                        s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4 << 20)
                        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        s.settimeout(60)
                        s.sendall(jutf_enc("LS3D") + jutf_enc(sid))
                        if rd(s, 1) != b"\x01":
                            raise OSError("sesi ditolak")
                        files = {}
                        buf = bytearray(CHUNK)
                        mv = memoryview(buf)
                        try:
                            while not err:
                                k = next(nxt)
                                if k >= len(chunks):
                                    break
                                i, off, ln = chunks[k]
                                f = files.get(i)
                                if f is None:
                                    f = files[i] = open(items[i][2], "rb", buffering=0)
                                f.seek(off)
                                s.sendall(struct.pack(">iqi", i, off, ln))
                                left = ln
                                while left > 0:
                                    m = f.readinto(mv[: min(CHUNK, left)])
                                    if not m:
                                        raise OSError("file berubah saat dikirim")
                                    s.sendall(mv[:m])
                                    left -= m
                                    x.add(m)
                            s.sendall(struct.pack(">i", -1))
                            rd(s, 1)
                        finally:
                            for f in files.values():
                                f.close()
                except Exception as e:
                    err.append(e)

            ts = [threading.Thread(target=worker, daemon=True) for _ in range(min(n, max(1, len(chunks))))]
            for t in ts:
                t.start()
            for t in ts:
                t.join()
            if err:
                raise err[0]
            ctl.settimeout(300)
            ctl.sendall(b"\x02")
            rd(ctl, 1)
        finally:
            ctl.close()

    def _send_legacy(self, host, port, items, total, x):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4 << 20)
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            s.settimeout(5)
            s.connect((host, port))
            s.settimeout(60)
            s.sendall(jutf_enc("LS1") + jutf_enc(self.name) + struct.pack(">iq", len(items), total))
            if rd(s, 1) != b"\x01":
                raise OSError("Ditolak")
            x.start()
            buf = bytearray(CHUNK)
            mv = memoryview(buf)
            for name, size, path in items:
                s.sendall(b"\x00" + jutf_enc(name) + struct.pack(">q", size))
                with open(path, "rb", buffering=0) as f:
                    left = size
                    while left > 0:
                        n = f.readinto(mv[: min(CHUNK, left)])
                        if not n:
                            raise OSError("file berubah saat dikirim")
                        s.sendall(mv[:n])
                        left -= n
                        x.add(n)
            s.sendall(b"\x02")
            rd(s, 1)
