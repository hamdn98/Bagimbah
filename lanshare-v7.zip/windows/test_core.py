"""Tes protokol tanpa GUI: meniru sisi Android memakai format byte Java yang sama."""
import os, socket, struct, tempfile, threading, time
from core import *

def test_utf():
    assert jutf_enc("A") == b"\x00\x01A"
    assert jutf_enc("é")[2:] == b"\xc3\xa9"
    assert jutf_enc("\u0000")[2:] == b"\xc0\x80"
    assert jutf_enc("😀")[2:] == bytes.fromhex("eda0bdedb880")  # surrogate pair 3+3 byte, ala Java
    for s in ["", "halo", "Galaxy A72", "é漢字😀\u0000x"]:
        e = jutf_enc(s)
        assert jutf_dec(e[2:]) == s

def mk(tmp):
    d = os.path.join(tmp, "rx"); n = Node(name="Laptop", save_dir=d, port=0, discovery=False)
    n.start(); return n

def test_ping_and_android_to_laptop():
    with tempfile.TemporaryDirectory() as tmp:
        n = mk(tmp)
        # PING seperti probe Android
        s = socket.create_connection(("127.0.0.1", n.port)); s.sendall(jutf_enc("PING"))
        assert read_utf(s) == "Laptop"; assert read_utf(s) == n.id; s.close()
        # Android -> laptop: 1 file biasa + 1 aplikasi 2 bagian
        data = os.urandom(3_000_000 + 17); apk1 = os.urandom(5000); apk2 = os.urandom(777)
        total = len(data) + len(apk1) + len(apk2)
        s = socket.create_connection(("127.0.0.1", n.port))
        s.sendall(jutf_enc("LS1") + jutf_enc("Galaxy A72") + struct.pack(">iq", 2, total))
        assert rd(s, 1) == b"\x01"
        s.sendall(b"\x00" + jutf_enc("foto ../bagus:1.bin") + struct.pack(">q", len(data)) + data)
        s.sendall(b"\x01" + jutf_enc("WhatsApp") + jutf_enc("com.whatsapp") + struct.pack(">i", 2)
                  + jutf_enc("base.apk") + struct.pack(">q", len(apk1)) + apk1
                  + jutf_enc("split_x.apk") + struct.pack(">q", len(apk2)) + apk2)
        s.sendall(b"\x02"); assert rd(s, 1) == b"\x01"; s.close()
        rx = os.path.join(tmp, "rx")
        assert open(os.path.join(rx, "bagus_1.bin"), "rb").read() == data
        assert open(os.path.join(rx, "Aplikasi", "com.whatsapp", "base.apk"), "rb").read() == apk1
        assert open(os.path.join(rx, "Aplikasi", "com.whatsapp", "split_x.apk"), "rb").read() == apk2
        time.sleep(0.2); assert n.xfers[0].state == 1

def test_reject():
    with tempfile.TemporaryDirectory() as tmp:
        n = Node(name="L", save_dir=tmp, port=0, discovery=False, on_offer=lambda *a: False); n.start()
        s = socket.create_connection(("127.0.0.1", n.port))
        s.sendall(jutf_enc("LS1") + jutf_enc("X") + struct.pack(">iq", 1, 10)); assert rd(s, 1) == b"\x00"

def test_laptop_to_android():
    """Server tiruan memakai urutan baca persis seperti Engine.handle() di Android."""
    with tempfile.TemporaryDirectory() as tmp:
        f1 = os.path.join(tmp, "a.bin"); f2 = os.path.join(tmp, "b.txt")
        d1 = os.urandom(2_500_000); d2 = b"halo"
        open(f1, "wb").write(d1); open(f2, "wb").write(d2)
        srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(1); got = {}
        def android():
            c, _ = srv.accept()
            assert read_utf(c) == "LS1"; got["from"] = read_utf(c)
            cnt, tot = struct.unpack(">iq", rd(c, 12)); got["cnt"], got["tot"] = cnt, tot
            c.sendall(b"\x01"); files = {}
            while True:
                k = rd(c, 1)[0]
                if k == 0:
                    nm = read_utf(c); (sz,) = struct.unpack(">q", rd(c, 8)); files[nm] = rd(c, sz)
                else: break
            c.sendall(b"\x01"); got["files"] = files
        t = threading.Thread(target=android); t.start()
        n = Node(name="Laptop", port=0, discovery=False)
        x = n.send_files("127.0.0.1", srv.getsockname()[1], [f1, f2]); t.join(10)
        assert x.state == 1, x.err
        assert got["from"] == "Laptop" and got["cnt"] == 2 and got["tot"] == len(d1) + 4
        assert got["files"] == {"a.bin": d1, "b.txt": d2}

def test_speed_loopback():
    with tempfile.TemporaryDirectory() as tmp:
        big = os.path.join(tmp, "big.bin"); open(big, "wb").write(os.urandom(200 * MB.__int__()))
        rx = mk(tmp); tx = Node(name="T", port=0, discovery=False)
        x = tx.send_files("127.0.0.1", rx.port, [big]); time.sleep(0.3)
        assert x.state == 1, x.err
        print(f"  loopback 200 MB: {x.speed:.0f} MB/s"); assert rx.xfers[0].state == 1


# ===== tes mode paralel (LS3) =====
def _mkfiles(tmp, sizes):
    ps = []
    for i, n in enumerate(sizes):
        p = os.path.join(tmp, f"f{i}.bin"); open(p, "wb").write(os.urandom(n)); ps.append(p)
    return ps

def test_parallel_py_to_py():
    with tempfile.TemporaryDirectory() as tmp:
        ps = _mkfiles(tmp, [9_000_001, 5_000_000, 100, 0])
        rx = mk(tmp); tx = Node(name="T", port=0, discovery=False)
        x = tx.send_files("127.0.0.1", rx.port, ps); time.sleep(0.3)
        assert x.state == 1, x.err
        got = sorted(os.listdir(os.path.join(tmp, "rx")))
        assert len(got) == 4, got
        for p in ps:
            assert open(os.path.join(tmp, "rx", os.path.basename(p)), "rb").read() == open(p, "rb").read()
        assert rx.xfers[0].state == 1 and rx.xfers[0].done == sum(os.path.getsize(p) for p in ps)

def test_parallel_android_sender_to_laptop():
    """Pengirim tiruan mengikuti persis Engine.sendParallel() di Android (2 worker)."""
    with tempfile.TemporaryDirectory() as tmp:
        n = mk(tmp); data = os.urandom(10_000_000)
        ctl = socket.create_connection(("127.0.0.1", n.port))
        ctl.sendall(jutf_enc("LS3") + jutf_enc("Galaxy A72") + struct.pack(">iq", 1, len(data)))
        assert rd(ctl, 1) == b"\x01"; sid = read_utf(ctl)
        ctl.sendall(jutf_enc("video.mp4") + struct.pack(">q", len(data))); assert rd(ctl, 1) == b"\x01"
        half = 4 << 20; frames = [(0, o, min(half, len(data) - o)) for o in range(0, len(data), half)]
        def worker(sub):
            s = socket.create_connection(("127.0.0.1", n.port)); s.sendall(jutf_enc("LS3D") + jutf_enc(sid))
            assert rd(s, 1) == b"\x01"
            for i, o, l in sub: s.sendall(struct.pack(">iqi", i, o, l) + data[o:o + l])
            s.sendall(struct.pack(">i", -1)); assert rd(s, 1) == b"\x01"; s.close()
        ts = [threading.Thread(target=worker, args=(frames[i::2],)) for i in range(2)]
        [t.start() for t in ts]; [t.join() for t in ts]
        ctl.sendall(b"\x02"); assert rd(ctl, 1) == b"\x01"
        assert open(os.path.join(tmp, "rx", "video.mp4"), "rb").read() == data

def test_parallel_laptop_to_android():
    """Penerima tiruan mengikuti Engine.handlePar()/handleData() di Android."""
    with tempfile.TemporaryDirectory() as tmp:
        ps = _mkfiles(tmp, [6_000_000, 4_500_000]); srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(8)
        out = {}
        def android():
            c, _ = srv.accept(); assert read_utf(c) == "LS3"; read_utf(c)
            cnt, tot = struct.unpack(">iq", rd(c, 12)); c.sendall(b"\x01"); c.sendall(jutf_enc("sid123"))
            sizes = []
            for _ in range(cnt): read_utf(c); sizes.append(struct.unpack(">q", rd(c, 8))[0])
            bufs = [bytearray(s) for s in sizes]; c.sendall(b"\x01")
            def data():
                d, _ = srv.accept(); assert read_utf(d) == "LS3D" and read_utf(d) == "sid123"; d.sendall(b"\x01")
                while True:
                    i, = struct.unpack(">i", rd(d, 4))
                    if i < 0: break
                    o, l = struct.unpack(">qi", rd(d, 12)); bufs[i][o:o + l] = rd(d, l)
                d.sendall(b"\x01")
            ts = [threading.Thread(target=data) for _ in range(PAR)]
            [t.start() for t in ts]; [t.join() for t in ts]
            assert rd(c, 1) == b"\x02"; c.sendall(b"\x01"); out["bufs"] = bufs
        t = threading.Thread(target=android); t.start()
        n = Node(name="Laptop", port=0, discovery=False)
        x = n.send_files("127.0.0.1", srv.getsockname()[1], ps); t.join(15)
        assert x.state == 1, x.err
        assert [bytes(b) for b in out["bufs"]] == [open(p, "rb").read() for p in ps]

def test_fallback_to_legacy_receiver():
    """Penerima versi lama menutup koneksi saat melihat tag selain LS1 -> pengirim harus mengulang dengan LS1."""
    with tempfile.TemporaryDirectory() as tmp:
        ps = _mkfiles(tmp, [6_000_000]); srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(4); got = {}
        def old():
            c, _ = srv.accept()
            if read_utf(c) != "LS1": c.close()
            c, _ = srv.accept(); assert read_utf(c) == "LS1"; read_utf(c)
            cnt, tot = struct.unpack(">iq", rd(c, 12)); c.sendall(b"\x01")
            assert rd(c, 1) == b"\x00"; nm = read_utf(c); sz, = struct.unpack(">q", rd(c, 8)); got["d"] = rd(c, sz)
            assert rd(c, 1) == b"\x02"; c.sendall(b"\x01")
        t = threading.Thread(target=old); t.start()
        n = Node(name="L", port=0, discovery=False)
        x = n.send_files("127.0.0.1", srv.getsockname()[1], ps); t.join(15)
        assert x.state == 1, x.err; assert got["d"] == open(ps[0], "rb").read()

def test_parallel_speed_loopback():
    with tempfile.TemporaryDirectory() as tmp:
        big = _mkfiles(tmp, [150 * 1048576])[0]; rx = mk(tmp); tx = Node(name="T", port=0, discovery=False)
        x = tx.send_files("127.0.0.1", rx.port, [big]); time.sleep(0.3)
        assert x.state == 1, x.err; print(f"  paralel loopback 150 MB: {x.speed:.0f} MB/s")
        assert os.path.getsize(os.path.join(tmp, "rx", "f0.bin")) == 150 * 1048576

if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"): v(); print("OK", k)
