package app.lanshare

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder

/** Menjaga LanShare tetap hidup di latar belakang supaya bisa menerima file saat layar mati / app diminimalkan. */
class KeepAliveService : Service() {
    companion object { const val ACTION_EXIT = "app.lanshare.EXIT" }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Engine.start(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val exit = PendingIntent.getService(
            this, 1, Intent(this, KeepAliveService::class.java).setAction(ACTION_EXIT), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, Engine.CH_LIVE)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), "Keluar", exit).build())
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("LanShare aktif")
            .setContentText("Siap menerima file")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_EXIT) { Engine.exitApp(null); return START_NOT_STICKY }
        return START_STICKY
    }
}
