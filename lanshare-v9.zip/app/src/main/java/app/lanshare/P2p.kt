package app.lanshare

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.MacAddress
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

/** Wi-Fi Direct: cari HP terdekat, sambungkan tanpa router / hotspot. */
@SuppressLint("MissingPermission")
object P2p {
    val devices = MutableStateFlow<List<WifiP2pDevice>>(emptyList())
    val status = MutableStateFlow("Belum mencari")
    val enabled = MutableStateFlow(true)
    val connected = MutableStateFlow(false)

    /** freq > 0: kunci ke channel tertentu; freq = 0: pilih berdasar band. */
    data class Chan(val label: String, val band: Int, val freq: Int)

    val CHANS = listOf(
        Chan("Otomatis 5 GHz (disarankan)", WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, 0),
        Chan("Otomatis 2,4 GHz", WifiP2pConfig.GROUP_OWNER_BAND_2GHZ, 0),
        Chan("Terserah sistem", WifiP2pConfig.GROUP_OWNER_BAND_AUTO, 0),
        Chan("5 GHz · ch 36", 0, 5180), Chan("5 GHz · ch 40", 0, 5200),
        Chan("5 GHz · ch 44", 0, 5220), Chan("5 GHz · ch 48", 0, 5240),
        Chan("5 GHz · ch 149", 0, 5745), Chan("5 GHz · ch 153", 0, 5765),
        Chan("5 GHz · ch 157", 0, 5785), Chan("5 GHz · ch 161", 0, 5805),
        Chan("2,4 GHz · ch 1", 0, 2412), Chan("2,4 GHz · ch 6", 0, 2437), Chan("2,4 GHz · ch 11", 0, 2462),
    )
    val chan = MutableStateFlow(CHANS[0])

    private lateinit var mgr: WifiP2pManager
    private lateinit var ch: WifiP2pManager.Channel
    private var ready = false

    fun init(c: Context) {
        if (ready) return
        val app = c.applicationContext
        val m = app.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager ?: run {
            status.value = "HP ini tidak mendukung Wi-Fi Direct"; return
        }
        mgr = m
        ch = m.initialize(app, app.mainLooper, null)
        val f = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(app, object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, i: Intent) {
                try {
                    when (i.action) {
                        WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION ->
                            enabled.value = i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                        WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION ->
                            mgr.requestPeers(ch) { l -> devices.value = l.deviceList.toList() }
                        WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION ->
                            mgr.requestConnectionInfo(ch) { info -> onInfo(info) }
                    }
                } catch (_: SecurityException) {
                    status.value = "Izin Wi-Fi Direct belum diberikan"
                }
            }
        }, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        ready = true
    }

    private fun onInfo(info: WifiP2pInfo) {
        connected.value = info.groupFormed
        if (info.groupFormed) {
            val go = info.groupOwnerAddress?.hostAddress
            status.value = if (info.isGroupOwner) "Terhubung · HP ini jadi host grup" else "Terhubung ke $go"
            Engine.rescanSoon()
            if (!info.isGroupOwner && go != null) Engine.probeAsync(go)
        } else {
            status.value = "Tidak terhubung"
        }
    }

    private fun listener(ok: String, fail: String) = object : WifiP2pManager.ActionListener {
        override fun onSuccess() { status.value = ok }
        override fun onFailure(reason: Int) {
            status.value = if (reason == WifiP2pManager.BUSY) "$fail (sibuk, coba lagi)" else "$fail (kode $reason)"
        }
    }

    fun discover() {
        if (!ready) return
        try { mgr.discoverPeers(ch, listener("Mencari HP terdekat…", "Gagal mencari")) }
        catch (_: SecurityException) { status.value = "Izin Wi-Fi Direct belum diberikan" }
    }

    fun connect(d: WifiP2pDevice) {
        if (!ready) return
        // Channel/band hanya berlaku kalau HP ini jadi host grup, jadi minta jadi host (intent maksimum).
        val c = chan.value
        val cfg = try {
            val b = WifiP2pConfig.Builder().setDeviceAddress(MacAddress.fromString(d.deviceAddress))
            if (c.freq > 0) b.setGroupOperatingFrequency(c.freq) else b.setGroupOperatingBand(c.band)
            b.build().apply { groupOwnerIntent = WifiP2pConfig.GROUP_OWNER_INTENT_MAX }
        } catch (_: Exception) {
            WifiP2pConfig().apply { deviceAddress = d.deviceAddress; wps.setup = WpsInfo.PBC }
        }
        try { mgr.connect(ch, cfg, listener("Menunggu ${d.deviceName} menerima… (${c.label})", "Gagal menyambung, coba channel lain")) }
        catch (_: SecurityException) { status.value = "Izin Wi-Fi Direct belum diberikan" }
    }

    fun disconnect() {
        if (!ready) return
        try { mgr.removeGroup(ch, listener("Terputus", "Gagal memutus")) } catch (_: SecurityException) {}
    }
}
