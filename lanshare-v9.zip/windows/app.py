import ctypes
import os
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from core import Node


def fmt(n):
    if n >= 1 << 30: return f"{n / (1 << 30):.1f} GB"
    if n >= 1 << 20: return f"{n / (1 << 20):.1f} MB"
    return f"{n // 1024} KB"


class App:
    def __init__(self, root):
        self.root = root
        self.offers = queue.Queue()
        self.auto = tk.BooleanVar(value=False)
        self.node = Node(on_offer=self.ask_offer)
        self.node.start()
        self.peers = []

        root.title("LanShare")
        root.geometry("720x560")
        root.minsize(600, 460)
        ico = os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(__file__)), "icon.ico")
        if os.path.exists(ico):
            try: root.iconbitmap(ico)
            except tk.TclError: pass
        style = ttk.Style()
        if "vista" in style.theme_names(): style.theme_use("vista")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))

        top = ttk.Frame(root, padding=14); top.pack(fill="x")
        ttk.Label(top, text="LanShare", style="Title.TLabel").pack(anchor="w")
        self.ip_var = tk.StringVar()
        ttk.Label(top, textvariable=self.ip_var, foreground="#666").pack(anchor="w")

        mid = ttk.LabelFrame(root, text="Perangkat terdekat (HP / laptop lain yang membuka LanShare)", padding=8)
        mid.pack(fill="both", expand=False, padx=14)
        self.dev = ttk.Treeview(mid, columns=("ip", "name"), show="headings", height=6, selectmode="browse")
        self.dev.heading("name", text="Nama"); self.dev.heading("ip", text="IP")
        self.dev.column("name", width=300); self.dev.column("ip", width=160)
        self.dev.pack(fill="both", expand=True)
        self.dev.bind("<Double-1>", lambda e: self.send())

        bar = ttk.Frame(root, padding=(14, 8)); bar.pack(fill="x")
        ttk.Button(bar, text="Kirim file…", command=self.send).pack(side="left")
        ttk.Button(bar, text="Pindai ulang", command=lambda: threading.Thread(target=self.node.scan, daemon=True).start()).pack(side="left", padx=6)
        ttk.Button(bar, text="Tambah IP", command=self.add_ip).pack(side="left")
        ttk.Button(bar, text="Buka folder terima", command=self.open_dir).pack(side="left", padx=6)
        ttk.Checkbutton(bar, text="Terima otomatis", variable=self.auto).pack(side="right")
        self.par = tk.StringVar(value="1")
        ttk.Combobox(bar, textvariable=self.par, values=["1", "2", "4"], width=3, state="readonly").pack(side="right", padx=(0, 12))
        ttk.Label(bar, text="Koneksi:").pack(side="right", padx=(0, 4))

        low = ttk.LabelFrame(root, text="Transfer", padding=8)
        low.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        self.tv = ttk.Treeview(low, columns=("t", "p", "s"), show="headings")
        self.tv.heading("t", text="Item"); self.tv.heading("p", text="Progres"); self.tv.heading("s", text="Status")
        self.tv.column("t", width=280); self.tv.column("p", width=150); self.tv.column("s", width=160)
        self.tv.pack(fill="both", expand=True)

        root.after(300, self.tick)

    # ----- terima -----
    def ask_offer(self, frm, count, total):
        """Dipanggil dari thread jaringan; jawaban diberikan oleh GUI."""
        if self.auto.get():
            return True
        ev, res = threading.Event(), [False]
        self.offers.put((frm, count, total, ev, res))
        ev.wait(30)
        return res[0]

    def tick(self):
        try:
            while True:
                frm, count, total, ev, res = self.offers.get_nowait()
                self.root.deiconify(); self.root.lift()
                self.root.attributes("-topmost", True); self.root.after(400, lambda: self.root.attributes("-topmost", False))
                res[0] = messagebox.askyesno("LanShare", f"{frm} ingin mengirim\n{count} item, {fmt(total)}\n\nTerima?")
                ev.set()
        except queue.Empty:
            pass
        n = self.node
        self.ip_var.set("IP kamu: " + (", ".join(n.my_ips) or "belum tersambung ke jaringan") + (" · memindai…" if n.scanning else ""))
        peers = n.peer_list()
        if peers != self.peers:
            sel = self.dev.selection()
            self.dev.delete(*self.dev.get_children())
            for h, name, port in peers:
                self.dev.insert("", "end", iid=f"{h}:{port}", values=(h, name))
            if sel and self.dev.exists(sel[0]): self.dev.selection_set(sel[0])
            self.peers = peers
        with n.lock:
            xs = list(n.xfers)
        for x in xs:
            pct = int(x.done * 100 / x.total) if x.total else (100 if x.state == 1 else 0)
            status = {1: f"Selesai · {x.speed:.1f} MB/s", 2: f"Gagal: {x.err}"}.get(x.state, f"{x.speed:.1f} MB/s")
            vals = (x.title, f"{pct}%  {fmt(x.done)}/{fmt(x.total)}", status)
            iid = str(x.id)
            if self.tv.exists(iid): self.tv.item(iid, values=vals)
            else: self.tv.insert("", 0, iid=iid, values=vals)
        self.root.after(300, self.tick)

    # ----- aksi -----
    def selected(self):
        s = self.dev.selection()
        if not s:
            messagebox.showinfo("LanShare", "Pilih perangkat tujuan dulu.")
            return None
        host, port = s[0].rsplit(":", 1)
        return host, int(port)

    def send(self):
        t = self.selected()
        if not t: return
        paths = filedialog.askopenfilenames(title="Pilih file untuk dikirim")
        if paths:
            self.node.parallel = int(self.par.get())
            threading.Thread(target=self.node.send_files, args=(t[0], t[1], list(paths)), daemon=True).start()

    def add_ip(self):
        ip = simpledialog.askstring("Tambah lewat IP", "IP perangkat tujuan (mis. 192.168.43.1):", parent=self.root)
        if ip:
            def run():
                if not self.node.add_manual(ip):
                    self.root.after(0, lambda: messagebox.showwarning("LanShare", "Tidak ditemukan. Pastikan LanShare terbuka di perangkat itu."))
            threading.Thread(target=run, daemon=True).start()

    def open_dir(self):
        os.makedirs(self.node.save_dir, exist_ok=True)
        os.startfile(self.node.save_dir) if hasattr(os, "startfile") else None


if __name__ == "__main__":
    try: ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception: pass
    root = tk.Tk()
    App(root)
    root.mainloop()
