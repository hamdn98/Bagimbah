# LanShare
Kirim file dan aplikasi terpasang HP ke HP lewat WiFi/LAN. Penemuan otomatis (NSD), transfer TCP langsung.
Build: push ke GitHub, Actions menghasilkan APK (Artifacts > LanShare-apk). Lokal: `gradle assembleRelease`.
