package app.lanshare

import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.coroutines.resume

data class Peer(val name: String, val host: String, val port: Int)
sealed interface Sendable { val label: String; val size: Long }
class FileItem(val uri: Uri, override val label: String, override val size: Long) : Sendable
class AppItem(val pkg: String, override val label: String, val parts: List<File>) : Sendable {
    override val size get() = parts.sumOf { it.length() }
}
data class Offer(val from: String, val count: Int, val total: Long, val answer: CompletableDeferred<Boolean>)
/** state: 0 jalan, 1 selesai, 2 gagal */
data class Xfer(val id: Long, val title: String, val outgoing: Boolean, val done: Long, val total: Long, val speed: Double, val state: Int)

object Engine {
    const val SERVICE_TYPE = "_lanshare._tcp."
    val peers = MutableStateFlow<List<Peer>>(emptyList())
    val xfers = MutableStateFlow<List<Xfer>>(emptyList())
    val incoming = MutableStateFlow<Offer?>(null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: Context
    private lateinit var nsd: NsdManager
    private var started = false
    private var myName = Build.MODEL ?: "Android"
    private val resolveLock = Mutex()
    private val deviceName get() = Build.MODEL ?: "Android"

    fun start(c: Context) {
        if (started) return
        started = true
        app = c.applicationContext
        nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
        scope.launch { serve() }
    }

    // ---------- penemuan perangkat (NSD / mDNS) ----------
    private fun discover() {
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                if (s.serviceName == myName) return
                scope.launch { resolveLock.withLock { resolve(s) } }
            }
            override fun onServiceLost(s: NsdServiceInfo) {
                peers.update { l -> l.filter { it.name != s.serviceName } }
            }
        })
    }

    private suspend fun resolve(s: NsdServiceInfo) {
        withTimeoutOrNull(4000) {
            suspendCancellableCoroutine<Unit> { cont ->
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(i: NsdServiceInfo, e: Int) { if (cont.isActive) cont.resume(Unit) }
                    override fun onServiceResolved(i: NsdServiceInfo) {
                        val h = i.host?.hostAddress
                        if (h != null && i.serviceName != myName) {
                            peers.update { l -> l.filter { it.name != i.serviceName } + Peer(i.serviceName, h, i.port) }
                        }
                        if (cont.isActive) cont.resume(Unit)
                    }
                })
            }
        }
    }

    // ---------- penerima ----------
    private suspend fun serve() {
        val server = ServerSocket(0)
        val info = NsdServiceInfo().apply { serviceName = deviceName; serviceType = SERVICE_TYPE; port = server.localPort }
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) { myName = i.serviceName; discover() }
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) { discover() }
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        })
        while (true) {
            val s = withContext(Dispatchers.IO) { server.accept() }
            scope.launch { handle(s) }
        }
    }

    private fun handle(s: Socket) {
        var meter: Meter? = null
        try {
            s.use {
                s.tcpNoDelay = true; s.receiveBufferSize = 1 shl 20; s.soTimeout = 30000
                val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 18))
                val out = DataOutputStream(s.getOutputStream())
                if (inp.readUTF() != "LS1") return
                val from = inp.readUTF(); val count = inp.readInt(); val total = inp.readLong()
                val ans = CompletableDeferred<Boolean>()
                incoming.value = Offer(from, count, total, ans)
                val ok = runBlocking { withTimeoutOrNull(30000) { ans.await() } } ?: false
                incoming.value = null
                out.writeByte(if (ok) 1 else 0); out.flush()
                if (!ok) return
                meter = Meter(System.nanoTime(), "Dari $from", false, total).also { it.push(0) }
                val installs = mutableListOf<Pair<String, File>>()
                loop@ while (true) {
                    when (inp.readByte().toInt()) {
                        0 -> {
                            val name = inp.readUTF(); val size = inp.readLong()
                            saveToDownloads(name, size, inp, meter!!)
                        }
                        1 -> {
                            inp.readUTF(); val pkg = inp.readUTF(); val n = inp.readInt()
                            val dir = File(app.cacheDir, "inbox/$pkg").apply { deleteRecursively(); mkdirs() }
                            repeat(n) {
                                val fn = File(inp.readUTF()).name; val sz = inp.readLong()
                                File(dir, fn).outputStream().use { o -> copyN(inp, o, sz, meter!!) }
                            }
                            installs += pkg to dir
                        }
                        else -> break@loop
                    }
                }
                out.writeByte(1); out.flush()
                meter!!.push(1)
                installs.forEach { (_, d) -> installApk(d) }
            }
        } catch (e: Exception) {
            incoming.value = null
            meter?.push(2)
        }
    }

    private fun saveToDownloads(name: String, size: Long, inp: InputStream, m: Meter) {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, File(name).name)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/LanShare")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Gagal simpan")
        app.contentResolver.openOutputStream(uri)!!.use { copyN(inp, it, size, m) }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        app.contentResolver.update(uri, v, null, null)
    }

    private fun installApk(dir: File) {
        val pi = app.packageManager.packageInstaller
        val sid = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(sid).use { ses ->
            dir.listFiles()!!.forEach { f ->
                f.inputStream().use { i -> ses.openWrite(f.name, 0, f.length()).use { o -> i.copyTo(o, 1 shl 16); ses.fsync(o) } }
            }
            val it = Intent(app, InstallReceiver::class.java).setAction("app.lanshare.INSTALL")
            val pend = PendingIntent.getBroadcast(app, sid, it, PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            ses.commit(pend.intentSender)
        }
    }

    // ---------- pengirim ----------
    fun sendUris(p: Peer, uris: List<Uri>) {
        scope.launch {
            val items = uris.map { u ->
                app.contentResolver.query(u, null, null, null, null)?.use { c ->
                    c.moveToFirst()
                    val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val z = c.getColumnIndex(OpenableColumns.SIZE)
                    FileItem(u, if (n >= 0) c.getString(n) else "file", if (z >= 0) c.getLong(z) else 0L)
                } ?: FileItem(u, "file", 0L)
            }
            send(p, items)
        }
    }

    fun sendApps(p: Peer, apps: List<AppEntry>) {
        scope.launch { send(p, apps.map { AppItem(it.pkg, it.label, it.parts) }) }
    }

    private fun send(peer: Peer, items: List<Sendable>) {
        val total = items.sumOf { it.size }
        val title = if (items.size == 1) items[0].label else "${items.size} item"
        val meter = Meter(System.nanoTime(), "Ke ${peer.name}: $title", true, total)
        meter.push(0)
        try {
            Socket().use { s ->
                s.tcpNoDelay = true; s.sendBufferSize = 1 shl 20
                s.connect(InetSocketAddress(peer.host, peer.port), 5000)
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 1 shl 18))
                val inp = DataInputStream(s.getInputStream())
                out.writeUTF("LS1"); out.writeUTF(deviceName); out.writeInt(items.size); out.writeLong(total); out.flush()
                s.soTimeout = 60000
                if (inp.readByte().toInt() != 1) throw IOException("Ditolak")
                for (x in items) when (x) {
                    is FileItem -> {
                        out.writeByte(0); out.writeUTF(x.label); out.writeLong(x.size)
                        app.contentResolver.openInputStream(x.uri)!!.use { copy(it, out, meter) }
                    }
                    is AppItem -> {
                        out.writeByte(1); out.writeUTF(x.label); out.writeUTF(x.pkg); out.writeInt(x.parts.size)
                        x.parts.forEach { f ->
                            out.writeUTF(f.name); out.writeLong(f.length())
                            f.inputStream().use { copy(it, out, meter) }
                        }
                    }
                }
                out.writeByte(2); out.flush()
                inp.readByte()
                meter.push(1)
            }
        } catch (e: Exception) { meter.push(2) }
    }

    // ---------- util ----------
    private fun copy(i: InputStream, o: OutputStream, m: Meter) {
        val b = ByteArray(1 shl 18)
        while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); m.add(n) }
    }
    private fun copyN(i: InputStream, o: OutputStream, n: Long, m: Meter) {
        val b = ByteArray(1 shl 18); var left = n
        while (left > 0) {
            val r = i.read(b, 0, minOf(b.size.toLong(), left).toInt())
            if (r < 0) throw EOFException()
            o.write(b, 0, r); left -= r; m.add(r)
        }
    }

    private fun upd(x: Xfer) {
        xfers.update { l -> if (l.any { it.id == x.id }) l.map { if (it.id == x.id) x else it } else listOf(x) + l }
    }

    private class Meter(val id: Long, val title: String, val out: Boolean, val total: Long) {
        var done = 0L; private var last = 0L; private val t0 = System.nanoTime()
        fun add(n: Int) {
            done += n
            val now = System.nanoTime()
            if (now - last > 200_000_000L) { last = now; push(0) }
        }
        fun push(state: Int) {
            val sec = maxOf((System.nanoTime() - t0) / 1e9, 0.001)
            upd(Xfer(id, title, out, done, total, done / 1048576.0 / sec, state))
        }
    }
}
