package app.lanshare

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Engine.start(this)
        setContent { LanTheme { Root() } }
    }
}

@Composable
fun LanTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFF7C9CFF))
        else -> lightColorScheme(primary = Color(0xFF3B5BDB))
    }
    MaterialTheme(colorScheme = cs, content = content)
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun Root() {
    val nav = rememberNavController()
    val tabs = listOf(
        Tab("kirim", "Kirim", Icons.AutoMirrored.Filled.Send),
        Tab("aplikasi", "Aplikasi", Icons.Default.Menu),
        Tab("riwayat", "Riwayat", Icons.Default.Check)
    )
    val cur = nav.currentBackStackEntryAsState().value?.destination?.route
    val offer by Engine.incoming.collectAsState()

    offer?.let { o ->
        AlertDialog(
            onDismissRequest = { o.answer.complete(false) },
            title = { Text("${o.from} ingin mengirim") },
            text = { Text("${o.count} item, ${fmt(o.total)}") },
            confirmButton = { TextButton({ o.answer.complete(true) }) { Text("Terima") } },
            dismissButton = { TextButton({ o.answer.complete(false) }) { Text("Tolak") } }
        )
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = cur == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true; restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, null) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(
            nav, startDestination = "kirim", modifier = Modifier.padding(pad),
            enterTransition = { fadeIn(tween(220)) }, exitTransition = { fadeOut(tween(220)) }
        ) {
            composable("kirim") { KirimScreen() }
            composable("aplikasi") { AplikasiScreen() }
            composable("riwayat") { RiwayatScreen() }
        }
    }
}
